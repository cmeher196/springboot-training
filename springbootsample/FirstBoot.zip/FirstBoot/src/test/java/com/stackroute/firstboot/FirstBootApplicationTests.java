package com.stackroute.firstboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
